/* ─── Bow Down Visuals — site auth bridge ───
   Runs on bowdownvisuals.com pages. Reads the Supabase session token from
   localStorage and relays it to the background worker, which attaches it as
   `Authorization: Bearer` on API calls. The API ignores cookies, so without
   this the extension always looks "signed out".
   Re-sends on storage changes (token refresh) and on load. */

(function () {
  function findToken() {
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!k || !k.startsWith("sb-") || !k.endsWith("-auth-token")) continue;
        const raw = localStorage.getItem(k);
        if (!raw) continue;
        const parsed = JSON.parse(raw);
        const token = parsed && parsed.access_token;
        if (token) return token;
      }
    } catch {
      /* private mode / parse error */
    }
    return null;
  }

  function relay() {
    const token = findToken();
    try {
      chrome.runtime.sendMessage({ type: "site-auth-token", token });
    } catch {
      /* extension context invalidated */
    }
  }

  // Send on load (slight delay — Supabase restores session async).
  relay();
  window.setTimeout(relay, 1500);
  window.setTimeout(relay, 5000);

  // Re-send when the token refreshes.
  window.addEventListener("storage", (e) => {
    if (e.key && e.key.startsWith("sb-") && e.key.endsWith("-auth-token")) relay();
  });
})();
