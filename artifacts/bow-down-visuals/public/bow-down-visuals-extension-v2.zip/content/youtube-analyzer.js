// Bow Down Visuals — YouTube helper content script.
// Runs on https://www.youtube.com/watch* pages.
// 1. Adds a gold "Analyze thumbnail" button under the video title — grabs the
//    thumbnail + title and asks the background worker for an AI breakdown.
// 2. Adds a "Copy idea to BDV" button — saves the video title + URL into the
//    extension's Saved tab (no credits, no API needed).

(async function () {
  "use strict";

  try {
    const s = await chrome.storage.sync.get({ enableYoutubeAnalyzer: true });
    if (s.enableYoutubeAnalyzer === false) return;
  } catch {
    /* storage unavailable — run anyway */
  }

  const BTN_ID = "bdv-analyze-btn";
  const IDEA_BTN_ID = "bdv-idea-btn";
  const OVERLAY_ID = "bdv-analysis-overlay";

  function getVideoId() {
    const m = location.href.match(/[?&]v=([A-Za-z0-9_-]{11})/);
    return m ? m[1] : null;
  }

  function getVideoTitle() {
    const el =
      document.querySelector("#title h1 yt-formatted-string") ||
      document.querySelector("h1.ytd-watch-metadata yt-formatted-string") ||
      document.querySelector("#title h1");
    return el ? el.textContent.trim() : document.title.replace(/ - YouTube$/, "");
  }

  /** Best-effort view/like counts from the watch page DOM. */
  function getVideoStats() {
    const stats = {};
    // Views: usually in the info row under the title.
    const info =
      document.querySelector("#info #info-text") ||
      document.querySelector("ytd-watch-metadata #info");
    if (info) stats.views = info.textContent.replace(/\s+/g, " ").trim().split("•")[0].trim();
    // Likes: the like button's aria-label, e.g. "like this video along with 12,345 other people".
    const likeBtn =
      document.querySelector('ytd-toggle-button-renderer #button[aria-label*="like this video"]') ||
      document.querySelector('[aria-label*="Like this video"]');
    if (likeBtn) {
      const label = likeBtn.getAttribute("aria-label") || "";
      const m = label.match(/([\d,.]+[KMB]?)/i);
      if (m) stats.likes = m[1];
    }
    return stats;
  }

  function getThumbnailUrl(videoId) {
    return `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`;
  }

  function ensureButtons() {
    const anchor =
      document.querySelector("#actions ytd-menu-renderer") ||
      document.querySelector("#top-row #title") ||
      document.querySelector("ytd-watch-metadata #actions");
    if (!anchor || !anchor.parentElement) return;

    if (!document.getElementById(BTN_ID)) {
      const btn = document.createElement("button");
      btn.id = BTN_ID;
      btn.type = "button";
      btn.innerHTML = "🦈 Analyze thumbnail";
      btn.addEventListener("click", onAnalyze);
      anchor.parentElement.insertBefore(btn, anchor);
    }
    if (!document.getElementById(IDEA_BTN_ID)) {
      const btn = document.createElement("button");
      btn.id = IDEA_BTN_ID;
      btn.type = "button";
      btn.innerHTML = "📥 Copy idea to BDV";
      btn.addEventListener("click", onCopyIdea);
      const ref = document.getElementById(BTN_ID);
      if (ref && ref.parentElement) ref.parentElement.insertBefore(btn, ref.nextSibling);
      else anchor.parentElement.insertBefore(btn, anchor);
    }
  }

  async function onCopyIdea() {
    const videoId = getVideoId();
    if (!videoId) return;
    const btn = document.getElementById(IDEA_BTN_ID);
    try {
      const res = await chrome.runtime.sendMessage({
        type: "BDV_SAVE_LOCAL",
        item: {
          kind: "video",
          url: location.href.split("&")[0],
          title: getVideoTitle(),
          pageUrl: location.href.split("&")[0],
          pageTitle: getVideoTitle(),
          thumb: getThumbnailUrl(videoId),
        },
      });
      if (btn) {
        const old = btn.innerHTML;
        btn.innerHTML = res && res.ok ? "✓ Saved!" : "✕ Failed";
        setTimeout(() => (btn.innerHTML = old), 1800);
      }
    } catch (e) {
      if (btn) {
        const old = btn.innerHTML;
        btn.innerHTML = "✕ Failed";
        setTimeout(() => (btn.innerHTML = old), 1800);
      }
    }
  }

  async function onAnalyze() {
    const videoId = getVideoId();
    if (!videoId) {
      showOverlay("Couldn't detect the video id on this page.", true);
      return;
    }
    showOverlay("Analyzing thumbnail… 🦈", false, true);

    const payload = {
      videoId,
      videoTitle: getVideoTitle(),
      thumbnailUrl: getThumbnailUrl(videoId),
    };

    let res;
    try {
      res = await chrome.runtime.sendMessage({
        type: "BDV_ANALYZE_THUMBNAIL",
        payload,
      });
    } catch (e) {
      showOverlay("Extension error — is the background worker running?", true);
      return;
    }

    if (!res || !res.ok) {
      const err = (res && res.error) || "unknown";
      const friendly = {
        signed_out: "You're not signed in on bowdownvisuals.com. Sign in there, then retry.",
        not_wired_up:
          "The site doesn't have the thumbnail-analysis endpoint yet — it's on the roadmap (see extension README).",
        network: "Couldn't reach bowdownvisuals.com. Check your connection.",
      }[err] || `Analysis failed: ${err}`;
      showOverlay(friendly, true);
      return;
    }
    showOverlay(res.analysis, false, false, payload.thumbnailUrl, getVideoStats());
  }

  function showOverlay(text, isError, loading = false, thumbUrl = null, stats = null) {
    closeOverlay();
    const ov = document.createElement("div");
    ov.id = OVERLAY_ID;

    const card = document.createElement("div");
    card.className = "bdv-card" + (isError ? " bdv-error" : "");

    const head = document.createElement("div");
    head.className = "bdv-head";
    head.innerHTML = "<span>🦈 Thumbnail analysis</span>";
    const x = document.createElement("button");
    x.className = "bdv-close";
    x.textContent = "✕";
    x.addEventListener("click", closeOverlay);
    head.appendChild(x);
    card.appendChild(head);

    if (thumbUrl) {
      const img = document.createElement("img");
      img.className = "bdv-thumb";
      img.src = thumbUrl;
      img.alt = "Video thumbnail";
      img.onerror = () => {
        img.onerror = null;
        img.src = thumbUrl.replace("maxresdefault", "hqdefault");
      };
      card.appendChild(img);
    }

    if (stats && (stats.views || stats.likes)) {
      const statRow = document.createElement("div");
      statRow.className = "bdv-stats";
      const parts = [];
      if (stats.views) parts.push("👁 " + stats.views);
      if (stats.likes) parts.push("👍 " + stats.likes + " likes");
      statRow.textContent = parts.join("   •   ");
      card.appendChild(statRow);
    }

    const body = document.createElement("div");
    body.className = "bdv-body" + (loading ? " bdv-loading" : "");
    body.textContent = text;
    card.appendChild(body);

    const foot = document.createElement("div");
    foot.className = "bdv-foot";
    foot.innerHTML =
      'Powered by <a href="https://bowdownvisuals.com" target="_blank">Bow Down Visuals</a>';
    card.appendChild(foot);

    ov.appendChild(card);
    ov.addEventListener("click", (e) => {
      if (e.target === ov) closeOverlay();
    });
    document.body.appendChild(ov);
  }

  function closeOverlay() {
    const ov = document.getElementById(OVERLAY_ID);
    if (ov) ov.remove();
  }

  // YouTube is an SPA: poll for the title area after navigations.
  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      closeOverlay();
      const a = document.getElementById(BTN_ID);
      if (a) a.remove();
      const b = document.getElementById(IDEA_BTN_ID);
      if (b) b.remove();
    }
    ensureButtons();
  }, 1500);
  ensureButtons();
})();
