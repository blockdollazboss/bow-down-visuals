// Bow Down Visuals — social save button content script.
// Runs on TikTok and Instagram video/post pages.
// Adds a floating gold "Save to BDV" button that stores the current page
// (URL + title) into the extension's Saved tab via the background worker.

(async function () {
  "use strict";

  try {
    const s = await chrome.storage.sync.get({ enableSocialSave: true });
    if (s.enableSocialSave === false) return;
  } catch {
    /* storage unavailable — run anyway */
  }

  const BTN_ID = "bdv-social-save-btn";

  /** Only show on actual video/post pages, not feeds or profiles. */
  function isVideoPage() {
    const url = location.href;
    // TikTok: tiktok.com/@user/video/123
    if (/tiktok\.com\/@[^/]+\/video\/\d+/.test(url)) return true;
    // Instagram: instagram.com/p/ABC/, /reel/ABC/, /re/ABC/
    if (/instagram\.com\/(p|reel|re)\/[A-Za-z0-9_-]+\/?/.test(url)) return true;
    return false;
  }

  function pageTitle() {
    const meta = document.querySelector('meta[property="og:title"]');
    if (meta && meta.content) return meta.content.trim();
    return document.title.replace(/\s*\|.*$/, "").trim() || location.href;
  }

  function pageThumb() {
    const meta = document.querySelector('meta[property="og:image"]');
    return meta && meta.content ? meta.content : "";
  }

  function ensureButton() {
    if (!isVideoPage()) {
      const old = document.getElementById(BTN_ID);
      if (old) old.remove();
      return;
    }
    if (document.getElementById(BTN_ID)) return;

    const btn = document.createElement("button");
    btn.id = BTN_ID;
    btn.type = "button";
    btn.innerHTML = "🦈 Save to BDV";
    btn.title = "Save this video to your Bow Down Visuals Saved tab";
    btn.addEventListener("click", async () => {
      const old = btn.innerHTML;
      btn.innerHTML = "Saving…";
      try {
        const res = await chrome.runtime.sendMessage({
          type: "BDV_SAVE_LOCAL",
          item: {
            kind: "video",
            url: location.href.split("?")[0],
            title: pageTitle(),
            pageUrl: location.href.split("?")[0],
            pageTitle: pageTitle(),
            thumb: pageThumb(),
          },
        });
        btn.innerHTML = res && res.ok ? "✓ Saved!" : "✕ Failed";
      } catch (e) {
        btn.innerHTML = "✕ Failed";
      }
      setTimeout(() => (btn.innerHTML = old), 1800);
    });
    document.body.appendChild(btn);
  }

  // Both sites are SPAs: re-check on navigation.
  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      const old = document.getElementById(BTN_ID);
      if (old) old.remove();
    }
    ensureButton();
  }, 1500);
  ensureButton();
})();
