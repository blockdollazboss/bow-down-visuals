// Bow Down Visuals — popup command center logic (v2).
// Tabs: Chat (page-aware), Tools (full site directory + quick AI),
// Analyze, Money (bonus/wheel/referrals/credits), Saved.
// Talks to the background service worker, which calls the site API with the
// user's site cookies. Response shapes are handled generically.

const $ = (id) => document.getElementById(id);

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

let apiBase = "https://bowdownvisuals.com";
let chatEnabled = true;
let signedIn = false;
let moneyLoaded = false;

function setStatus(t) {
  $("status").textContent = t;
}

function extractReply(data) {
  if (!data) return null;
  if (typeof data === "string") return data;
  return (
    data.reply ||
    data.message ||
    data.text ||
    data.response ||
    data.analysis ||
    (data.data && (data.data.reply || data.data.message || data.data.text)) ||
    null
  );
}

function extractCredits(data) {
  if (!data || typeof data !== "object") return null;
  const v =
    data.credits ??
    data.balance ??
    data.creditsRemaining ??
    data.creditBalance ??
    (data.data && (data.data.credits ?? data.data.balance));
  return typeof v === "number" ? v : null;
}

function showCredits(n) {
  $("credit-count").textContent = n;
  $("credits").classList.remove("hidden");
}

function sendBg(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (res) => {
      if (chrome.runtime.lastError) resolve(null);
      else resolve(res);
    });
  });
}

function showAuthWarning() {
  signedIn = false;
  $("auth-warning").classList.remove("hidden");
  setStatus("Not signed in");
}

/** Copy text to clipboard with a tiny inline confirmation. */
async function copyText(text, btn) {
  try {
    await navigator.clipboard.writeText(text);
    if (btn) {
      const old = btn.textContent;
      btn.textContent = "✓";
      setTimeout(() => (btn.textContent = old), 1200);
    }
  } catch {
    /* clipboard unavailable */
  }
}

/** Render a result box: loading / error / text, with optional per-line copy. */
function renderResult(el, state, text, copyLines = false) {
  el.classList.remove("hidden", "loading", "error");
  if (state === "loading") {
    el.classList.add("loading");
    el.textContent = "Working… 🦈";
    return;
  }
  if (state === "error") {
    el.classList.add("error");
    el.textContent = text;
    return;
  }
  el.textContent = "";
  if (copyLines && Array.isArray(text)) {
    text.forEach((line) => {
      const row = document.createElement("div");
      row.className = "hook-row";
      const span = document.createElement("span");
      span.textContent = line;
      const btn = document.createElement("button");
      btn.className = "copy-btn";
      btn.textContent = "Copy";
      btn.addEventListener("click", () => copyText(line, btn));
      row.appendChild(span);
      row.appendChild(btn);
      el.appendChild(row);
    });
    if (!text.length) el.textContent = "(empty reply from the site)";
  } else {
    el.textContent = text;
  }
}

function signedOutError() {
  showAuthWarning();
  return "Not signed in on bowdownvisuals.com.";
}

// ---------------------------------------------------------------------------
// Tabs
// ---------------------------------------------------------------------------

function switchTab(name) {
  document.querySelectorAll(".tab").forEach((b) =>
    b.classList.toggle("active", b.dataset.tab === name)
  );
  document.querySelectorAll(".pane").forEach((p) =>
    p.classList.toggle("active", p.id === "tab-" + name)
  );
  if (name === "saved") loadSaved();
  if (name === "analyze") detectYoutube();
  if (name === "money" && !moneyLoaded) loadMoney();
}

document.querySelectorAll(".tab").forEach((b) =>
  b.addEventListener("click", () => switchTab(b.dataset.tab))
);

// ---------------------------------------------------------------------------
// Chat tab (page-aware in v2)
// ---------------------------------------------------------------------------

const messagesEl = $("messages");
const chatForm = $("chat-form");
const chatInput = $("chat-input");
const sendBtn = $("send-btn");
let pageContext = null;

function addMsg(role, text, isError = false) {
  const div = document.createElement("div");
  div.className = "msg " + (isError ? "error" : role);
  if (role === "assistant" && !isError) {
    const who = document.createElement("span");
    who.className = "who";
    who.textContent = "🦈 Thy Cheat Code";
    div.appendChild(who);
    div.appendChild(document.createTextNode(text));
  } else {
    div.textContent = text;
  }
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return div;
}

$("page-btn").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url) return;
  let selection = "";
  try {
    const res = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => window.getSelection ? window.getSelection().toString().slice(0, 2000) : "",
    });
    selection = (res && res[0] && res[0].result) || "";
  } catch {
    /* scripting unavailable on this page (e.g. chrome://) */
  }
  pageContext = { title: tab.title || "", url: tab.url, selection };
  $("page-context-label").textContent =
    "📄 " + (tab.title ? tab.title.slice(0, 40) : tab.url.slice(0, 40)) + (selection ? " + selection" : "");
  $("page-context-bar").classList.remove("hidden");
});

$("page-context-clear").addEventListener("click", () => {
  pageContext = null;
  $("page-context-bar").classList.add("hidden");
});

async function sendChatMessage(text) {
  if (!text || sendBtn.disabled) return;
  addMsg("user", text);
  chatInput.value = "";
  sendBtn.disabled = true;
  setStatus("Thinking…");
  const typing = addMsg("assistant", "…", false);
  typing.classList.add("typing");

  let message = text;
  if (pageContext) {
    message =
      "[Context: the user is looking at this page — Title: \"" +
      pageContext.title.slice(0, 200) + "\" URL: " + pageContext.url.slice(0, 300) +
      (pageContext.selection ? " Selected text: \"" + pageContext.selection.slice(0, 1500) + "\"" : "") +
      "] " + text;
  }

  const res = await sendBg({ type: "BDV_CHAT_SEND", message });
  typing.remove();
  sendBtn.disabled = false;

  if (!res) {
    addMsg("assistant", "Couldn't reach the site. Check your connection.", true);
    setStatus("Error");
    return;
  }
  if (res.status === 401 || res.status === 403) {
    showAuthWarning();
    addMsg("assistant", "You're not signed in on bowdownvisuals.com — sign in there first, then try again.", true);
    return;
  }
  if (!res.ok) {
    const d = res.data || {};
    addMsg("assistant", d.error || d.message || `The site returned ${res.status}.`, true);
    setStatus("Error");
    return;
  }
  addMsg("assistant", extractReply(res.data) || "(empty reply from the site)");
  const c = extractCredits(res.data);
  if (c !== null) showCredits(c);
  setStatus("Ready");
  $("auth-warning").classList.add("hidden");
}

chatForm.addEventListener("submit", (e) => {
  e.preventDefault();
  sendChatMessage(chatInput.value.trim());
});

// ---------------------------------------------------------------------------
// Tools tab — quick AI generators + full site directory
// ---------------------------------------------------------------------------

function openSitePath(path) {
  chrome.tabs.create({ url: apiBase.replace(/\/+$/, "") + path });
}

$("hooks-btn").addEventListener("click", async () => {
  const topic = $("hooks-input").value.trim();
  if (!topic) return;
  const el = $("hooks-result");
  const btn = $("hooks-btn");
  btn.disabled = true;
  renderResult(el, "loading");
  const res = await sendBg({ type: "BDV_HOOKS", topic });
  btn.disabled = false;
  if (!res) return renderResult(el, "error", "Couldn't reach the extension worker.");
  if (res.error === "signed_out") return renderResult(el, "error", signedOutError());
  if (!res.ok) return renderResult(el, "error", String(res.error || "Failed."));
  renderResult(el, "ok", res.hooks, true);
});

$("caption-btn").addEventListener("click", async () => {
  const topic = $("caption-input").value.trim();
  if (!topic) return;
  const el = $("caption-result");
  const btn = $("caption-btn");
  btn.disabled = true;
  renderResult(el, "loading");
  const res = await sendBg({ type: "BDV_CAPTION", topic });
  btn.disabled = false;
  if (!res) return renderResult(el, "error", "Couldn't reach the extension worker.");
  if (res.error === "signed_out") return renderResult(el, "error", signedOutError());
  if (!res.ok) return renderResult(el, "error", String(res.error || "Failed."));
  renderResult(el, "ok", res.result);
});

$("viral-btn").addEventListener("click", async () => {
  const idea = $("viral-input").value.trim();
  if (!idea) return;
  const el = $("viral-result");
  const btn = $("viral-btn");
  btn.disabled = true;
  renderResult(el, "loading");
  const res = await sendBg({ type: "BDV_VIRALITY", idea });
  btn.disabled = false;
  if (!res) return renderResult(el, "error", "Couldn't reach the extension worker.");
  if (res.error === "signed_out") return renderResult(el, "error", signedOutError());
  if (!res.ok) return renderResult(el, "error", String(res.error || "Failed."));
  renderResult(el, "ok", res.result);
});

$("dice-btn").addEventListener("click", async () => {
  const el = $("dice-result");
  const btn = $("dice-btn");
  btn.disabled = true;
  renderResult(el, "loading");
  const res = await sendBg({ type: "BDV_IDEA_DICE" });
  btn.disabled = false;
  if (!res) return renderResult(el, "error", "Couldn't reach the extension worker.");
  if (res.error === "signed_out") return renderResult(el, "error", signedOutError());
  if (!res.ok) return renderResult(el, "error", String(res.error || "Failed."));
  renderResult(el, "ok", "🎲 Niche: " + res.niche + "\n\n" + res.result);
});

// ---- Full site tool directory ----

function renderTools(filter) {
  const list = $("tools-list");
  list.innerHTML = "";
  const q = (filter || "").trim().toLowerCase();

  BDV_CATEGORIES.forEach((cat) => {
    const tools = BDV_TOOLS.filter((t) => {
      if (t.c !== cat.id) return false;
      if (!q) return true;
      return (
        t.n.toLowerCase().includes(q) ||
        t.d.toLowerCase().includes(q) ||
        t.p.toLowerCase().includes(q)
      );
    });
    if (!tools.length) return;

    const h = document.createElement("h4");
    h.className = "tools-cat";
    h.textContent = cat.icon + " " + cat.name + " (" + tools.length + ")";
    list.appendChild(h);

    const grid = document.createElement("div");
    grid.className = "tools-grid";
    tools.forEach((t) => {
      const b = document.createElement("button");
      b.className = "tool-link";
      b.title = t.d + "\n" + t.p;
      const ic = document.createElement("span");
      ic.className = "tool-link-icon";
      ic.textContent = t.i;
      const nm = document.createElement("span");
      nm.className = "tool-link-name";
      nm.textContent = t.n;
      b.appendChild(ic);
      b.appendChild(nm);
      b.addEventListener("click", () => openSitePath(t.p));
      grid.appendChild(b);
    });
    list.appendChild(grid);
  });

  if (!list.children.length) {
    const p = document.createElement("p");
    p.className = "desc";
    p.textContent = "No tools match \"" + filter + "\".";
    list.appendChild(p);
  }
}

$("tools-search").addEventListener("input", (e) => renderTools(e.target.value));

// ---------------------------------------------------------------------------
// Analyze tab
// ---------------------------------------------------------------------------

$("analyze-page-btn").addEventListener("click", async () => {
  const el = $("analyze-page-result");
  const btn = $("analyze-page-btn");
  btn.disabled = true;
  renderResult(el, "loading");
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const res = await sendBg({
    type: "BDV_ANALYZE_PAGE",
    url: tab ? tab.url : "",
    title: tab ? tab.title : "",
  });
  btn.disabled = false;
  if (!res) return renderResult(el, "error", "Couldn't reach the extension worker.");
  if (res.error === "signed_out") return renderResult(el, "error", signedOutError());
  if (!res.ok) return renderResult(el, "error", String(res.error || "Failed."));
  renderResult(el, "ok", res.result);
});

async function detectYoutube() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = tab && tab.url ? tab.url : "";
  const m = url.match(/[?&]v=([A-Za-z0-9_-]{11})/);
  const section = $("yt-section");
  if (!m || !url.includes("youtube.com/watch")) {
    section.classList.add("hidden");
    return;
  }
  section.classList.remove("hidden");
  $("yt-title").textContent = tab.title ? tab.title.replace(/ - YouTube$/, "") : "";
  $("yt-analyze-btn").onclick = async () => {
    const el = $("yt-result");
    const btn = $("yt-analyze-btn");
    btn.disabled = true;
    renderResult(el, "loading");
    const res = await sendBg({
      type: "BDV_ANALYZE_THUMBNAIL",
      payload: {
        videoId: m[1],
        videoTitle: tab.title ? tab.title.replace(/ - YouTube$/, "") : "",
        thumbnailUrl: `https://i.ytimg.com/vi/${m[1]}/maxresdefault.jpg`,
      },
    });
    btn.disabled = false;
    if (!res || !res.ok) {
      const err = (res && res.error) || "unknown";
      const friendly = {
        signed_out: "Not signed in on bowdownvisuals.com.",
        not_wired_up: "The site's thumbnail-analysis endpoint isn't wired up yet.",
        network: "Couldn't reach bowdownvisuals.com.",
      }[err] || `Analysis failed: ${err}`;
      return renderResult(el, "error", friendly);
    }
    renderResult(el, "ok", res.analysis);
  };
}

$("comp-btn").addEventListener("click", async () => {
  const url = $("comp-input").value.trim();
  if (!url) return;
  const el = $("comp-result");
  const btn = $("comp-btn");
  btn.disabled = true;
  renderResult(el, "loading");
  const res = await sendBg({ type: "BDV_COMPETITOR", url });
  btn.disabled = false;
  if (!res) return renderResult(el, "error", "Couldn't reach the extension worker.");
  if (res.error === "signed_out") return renderResult(el, "error", signedOutError());
  if (!res.ok) return renderResult(el, "error", String(res.error || "Failed."));
  renderResult(el, "ok", res.result);
});

// ---------------------------------------------------------------------------
// Money tab — daily bonus, wheel, referrals, credit usage
// ---------------------------------------------------------------------------

function fmtCooldown(secs) {
  if (secs == null) return "";
  const s = Math.max(0, Math.floor(secs));
  const m = Math.floor(s / 60);
  if (m < 1) return s + "s";
  if (m < 60) return m + "m";
  return Math.floor(m / 60) + "h " + (m % 60) + "m";
}

async function loadMoney() {
  moneyLoaded = true;

  // ---- Daily bonus + wheel ----
  const bonusBtn = $("bonus-claim-btn");
  const wheelBtn = $("wheel-spin-btn");
  const bRes = await sendBg({ type: "BDV_BONUS_STATUS" });
  if (!bRes) {
    $("bonus-streak").textContent = "–";
  } else if (bRes.error === "signed_out") {
    showAuthWarning();
    $("bonus-streak").textContent = "–";
    $("wheel-status").textContent = "Sign in on bowdownvisuals.com to use bonuses.";
    bonusBtn.disabled = true;
    wheelBtn.disabled = true;
  } else if (bRes.ok && bRes.status) {
    const st = bRes.status;
    $("bonus-streak").textContent = st.streak != null ? st.streak : "0";
    if (st.canClaimDaily) {
      bonusBtn.disabled = false;
      bonusBtn.textContent = "Claim daily bonus";
    } else {
      bonusBtn.disabled = true;
      bonusBtn.textContent = "Claimed — come back tomorrow";
    }
    const cd = st.wheelCooldownSeconds;
    if (cd && cd > 0) {
      $("wheel-status").textContent = "Next spin in ~" + fmtCooldown(cd) + ".";
      wheelBtn.disabled = true;
    } else {
      $("wheel-status").textContent = "Your hourly spin is ready. 🦈";
      wheelBtn.disabled = false;
    }
  }

  bonusBtn.addEventListener("click", async () => {
    bonusBtn.disabled = true;
    renderResult($("bonus-result"), "loading");
    const res = await sendBg({ type: "BDV_BONUS_CLAIM" });
    if (!res) return renderResult($("bonus-result"), "error", "Couldn't reach the extension worker.");
    if (res.error === "signed_out") return renderResult($("bonus-result"), "error", signedOutError());
    if (!res.ok || !res.result || !res.result.claimed) {
      const reason = (res.result && res.result.reason) || res.error || "Failed.";
      renderResult($("bonus-result"), "error", "Couldn't claim: " + reason);
      bonusBtn.disabled = false;
      return;
    }
    const r = res.result;
    renderResult(
      $("bonus-result"),
      "ok",
      "✅ +" + r.bonusGranted + " bonus credits claimed! Streak: " + r.streak + " day(s)." +
        (r.isStreakMilestone ? " 🏆 Milestone bonus!" : "")
    );
    $("bonus-streak").textContent = r.streak;
    bonusBtn.textContent = "Claimed — come back tomorrow";
  });

  wheelBtn.addEventListener("click", async () => {
    wheelBtn.disabled = true;
    renderResult($("wheel-result"), "loading");
    const res = await sendBg({ type: "BDV_BONUS_SPIN" });
    if (!res) {
      wheelBtn.disabled = false;
      return renderResult($("wheel-result"), "error", "Couldn't reach the extension worker.");
    }
    if (res.error === "signed_out") {
      wheelBtn.disabled = false;
      return renderResult($("wheel-result"), "error", signedOutError());
    }
    if (res.error === "cooldown") {
      renderResult($("wheel-result"), "error", "On cooldown — next spin in ~" + fmtCooldown(res.cooldownSeconds) + ".");
      return;
    }
    if (!res.ok || !res.result || !res.result.spun) {
      wheelBtn.disabled = false;
      return renderResult($("wheel-result"), "error", String(res.error || "Spin failed."));
    }
    const r = res.result;
    renderResult(
      $("wheel-result"),
      "ok",
      (r.isJackpot ? "🎰 JACKPOT! " : "🎡 ") + "+" + r.prize + " credits (" + r.label + ")"
    );
    $("wheel-status").textContent = "Next spin in about an hour.";
  });

  // ---- Referrals ----
  const rRes = await sendBg({ type: "BDV_REFERRAL" });
  if (rRes && rRes.ok && rRes.info) {
    const info = rRes.info;
    const link = apiBase + "/signup?ref=" + info.code;
    $("referral-link").value = link;
    const tierTxt = info.tier ? " • " + info.tier.title + " (" + info.tier.ratePct + "%)" : "";
    $("referral-stats").textContent =
      (info.totalReferrals || 0) + " referrals • " +
      (info.creditsEarned || 0) + " credits earned" + tierTxt +
      " — friends get " + (info.refereeReward || 10) + " welcome credits.";
    $("referral-copy-btn").addEventListener("click", (e) =>
      copyText(link, e.target)
    );
  } else {
    $("referral-stats").textContent =
      rRes && rRes.error === "signed_out"
        ? "Sign in to see your referral stats."
        : "Couldn't load referral info.";
    $("referral-copy-btn").disabled = true;
  }
  $("referral-open-btn").addEventListener("click", () => openSitePath("/referrals"));

  // ---- Credit usage ----
  const hRes = await sendBg({ type: "BDV_CREDITS_HISTORY" });
  const usageEl = $("credits-usage");
  usageEl.innerHTML = "";
  if (hRes && hRes.ok && hRes.history) {
    const usage = hRes.history.usage || [];
    if (!usage.length) {
      usageEl.innerHTML = '<p class="desc">No usage yet.</p>';
    } else {
      usage.slice(0, 6).forEach((u) => {
        const row = document.createElement("div");
        row.className = "usage-row";
        const what = document.createElement("span");
        what.textContent = u.label || u.action || u.type || "Usage";
        const amt = document.createElement("span");
        amt.className = "usage-amt";
        amt.textContent = "−" + (u.credits ?? u.amount ?? "?");
        row.appendChild(what);
        row.appendChild(amt);
        usageEl.appendChild(row);
      });
    }
  } else {
    usageEl.innerHTML = '<p class="desc">Couldn\'t load usage.</p>';
  }

  $("buy-credits-btn").addEventListener("click", () => openSitePath("/pricing"));
}

// ---------------------------------------------------------------------------
// Saved tab
// ---------------------------------------------------------------------------

const KIND_ICON = { image: "🖼️", video: "🎬", link: "🔗" };

function timeAgo(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return Math.floor(s / 60) + "m ago";
  if (s < 86400) return Math.floor(s / 3600) + "h ago";
  return Math.floor(s / 86400) + "d ago";
}

async function loadSaved() {
  const res = await sendBg({ type: "BDV_GET_SAVED" });
  const items = (res && res.items) || [];
  const list = $("saved-list");
  list.innerHTML = "";

  const count = $("saved-count");
  if (items.length) {
    count.textContent = items.length;
    count.classList.remove("hidden");
  } else {
    count.classList.add("hidden");
  }
  $("saved-clear").classList.toggle("hidden", !items.length);

  if (!items.length) {
    const p = document.createElement("p");
    p.className = "desc";
    p.textContent = "Nothing saved yet.";
    list.appendChild(p);
    return;
  }

  items.forEach((item) => {
    const row = document.createElement("div");
    row.className = "saved-item";

    if (item.thumb) {
      const img = document.createElement("img");
      img.className = "saved-thumb";
      img.src = item.thumb;
      img.alt = "";
      img.onerror = () => img.remove();
      row.appendChild(img);
    } else {
      const badge = document.createElement("div");
      badge.className = "saved-thumb kind";
      badge.textContent = KIND_ICON[item.kind] || "🔗";
      row.appendChild(badge);
    }

    const meta = document.createElement("div");
    meta.className = "saved-meta";
    const title = document.createElement("div");
    title.className = "saved-title";
    title.textContent = item.title || item.url;
    title.title = item.title || item.url;
    const sub = document.createElement("div");
    sub.className = "saved-sub";
    sub.textContent = timeAgo(item.ts);
    const kind = document.createElement("span");
    kind.className = "saved-kind";
    kind.textContent = item.kind || "link";
    meta.appendChild(title);
    meta.appendChild(sub);
    meta.appendChild(kind);
    row.appendChild(meta);

    const actions = document.createElement("div");
    actions.className = "saved-actions";
    const open = document.createElement("button");
    open.textContent = "Open";
    open.addEventListener("click", () => chrome.tabs.create({ url: item.url }));
    const del = document.createElement("button");
    del.textContent = "✕";
    del.className = "del";
    del.title = "Delete";
    del.addEventListener("click", async () => {
      await sendBg({ type: "BDV_DELETE_SAVED", id: item.id });
      loadSaved();
    });
    actions.appendChild(open);
    actions.appendChild(del);
    row.appendChild(actions);

    list.appendChild(row);
  });
}

$("saved-clear").addEventListener("click", async () => {
  await sendBg({ type: "BDV_CLEAR_SAVED" });
  loadSaved();
});

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------

async function boot() {
  const settings = await chrome.storage.sync.get({
    apiBase: "https://bowdownvisuals.com",
    enableChat: true,
  });
  apiBase = (settings.apiBase || "https://bowdownvisuals.com").replace(/\/+$/, "");
  chatEnabled = settings.enableChat !== false;

  $("signin-link").href = apiBase + "/login";
  $("open-site").href = apiBase;

  renderTools("");

  if (!chatEnabled) {
    setStatus("Chat disabled in options");
    chatInput.disabled = true;
    sendBtn.disabled = true;
    addMsg("assistant", "Chat is disabled in the extension options.", true);
  } else {
    addMsg("assistant", "Yo — Thy Cheat Code here. 🦈 Ask me anything about content, hooks, thumbnails, or your next drop. Hit 📄 to attach the page you're on.");
    setStatus("Checking sign-in…");

    const res = await sendBg({ type: "BDV_CHAT_STATUS" });
    if (!res) {
      setStatus("Couldn't reach the site");
    } else if (res.ok) {
      signedIn = true;
      $("auth-warning").classList.add("hidden");
      setStatus("Connected");
      const c = extractCredits(res.data);
      if (c !== null) showCredits(c);
    } else if (res.status === 401 || res.status === 403) {
      showAuthWarning();
    } else if (res.status === 404) {
      setStatus("Ready");
    } else {
      setStatus("Site unreachable");
    }
  }

  // Omnibox pre-fill: if the user typed `bdv <query>` in the address bar,
  // drop it into the chat box (and switch to the Chat tab).
  const pq = await sendBg({ type: "BDV_CONSUME_PENDING_QUERY" });
  if (pq && pq.query) {
    switchTab("chat");
    chatInput.value = pq.query;
    chatInput.focus();
  }

  // Saved badge count on the tab.
  const saved = await sendBg({ type: "BDV_GET_SAVED" });
  if (saved && saved.items && saved.items.length) {
    $("saved-count").textContent = saved.items.length;
    $("saved-count").classList.remove("hidden");
  }
}

document.addEventListener("DOMContentLoaded", boot);
