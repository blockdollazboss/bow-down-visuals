// Bow Down Visuals — complete site tool directory (v2).
// Every creator tool on bowdownvisuals.com, organized by category.
// Loaded by popup.html before popup.js. Rendered into the Tools tab.

const BDV_CATEGORIES = [
  { id: "start", icon: "🚀", name: "Start here" },
  { id: "video", icon: "🎬", name: "Video" },
  { id: "music", icon: "🎵", name: "Music" },
  { id: "images", icon: "🎨", name: "Images & Brand" },
  { id: "content", icon: "✍️", name: "Content & Writing" },
  { id: "promote", icon: "📣", name: "Promote & Grow" },
  { id: "money", icon: "💰", name: "Money" },
  { id: "library", icon: "📂", name: "Library & Account" },
  { id: "learn", icon: "📚", name: "Learn & Business" },
];

// { n: name, p: path, i: icon, c: category, d: short description }
const BDV_TOOLS = [
  // ---- Start here ----
  { n: "Create — what are you making?", p: "/create", i: "✨", c: "start", d: "Guided picker: music video, promo, lyric video, vlog, short, slideshow, intro/outro" },
  { n: "Creation Hub", p: "/hub", i: "🌀", c: "start", d: "One unified hub where beats flow into songs into videos into promos" },
  { n: "Dashboard", p: "/dashboard", i: "🏠", c: "start", d: "Your home base on the site" },

  // ---- Video ----
  { n: "Make Video", p: "/make-video", i: "🎥", c: "video", d: "AI video generation (Runway, Seedance)" },
  { n: "Video Editor", p: "/video-editor", i: "🎬", c: "video", d: "Full pro editor — trim, split, captions, effects, color grade" },
  { n: "Promo Clips", p: "/promo-clip", i: "📝", c: "video", d: "Turn songs and videos into promo clips" },
  { n: "Clip Maker", p: "/clip-maker", i: "✂️", c: "video", d: "Cut highlights and short clips" },
  { n: "Lyric Video", p: "/lyric-video", i: "🎤", c: "video", d: "Animated lyric videos for your songs" },
  { n: "Repurpose", p: "/repurpose", i: "♻️", c: "video", d: "Turn one video into many formats" },
  { n: "Upscale", p: "/upscale", i: "🔍", c: "video", d: "Upscale clips to higher resolution" },
  { n: "Watermark Removal", p: "/watermark-removal", i: "💧", c: "video", d: "Clean watermarks off your own content" },
  { n: "Intros & Outros", p: "/intros-outros", i: "🎞️", c: "video", d: "Branded video intros and outros" },
  { n: "Movies & Series", p: "/movies", i: "🎬", c: "video", d: "Movies & web series tools + AI streamer clipping" },
  { n: "Caption Styler", p: "/caption-styler", i: "💬", c: "video", d: "Styled captions for clips" },
  { n: "Translate", p: "/translate", i: "🌍", c: "video", d: "Translate content for new audiences" },
  { n: "Voiceover", p: "/voiceover", i: "🎙️", c: "video", d: "AI voiceovers" },
  { n: "My Clips", p: "/my-clips", i: "📁", c: "video", d: "Your saved clips library" },

  // ---- Music ----
  { n: "Make Song", p: "/make-song", i: "🎵", c: "music", d: "AI song generation" },
  { n: "Song + Video", p: "/song-and-video", i: "🎵", c: "music", d: "Make the song and its video together" },
  { n: "My Songs", p: "/songs", i: "🎶", c: "music", d: "Your song library" },
  { n: "Beat Maker", p: "/beat-maker", i: "🥁", c: "music", d: "AI beats + step sequencer" },
  { n: "Beats", p: "/beats", i: "🥁", c: "music", d: "Browse and manage beats" },
  { n: "Stems", p: "/stems", i: "🎚️", c: "music", d: "Split songs into stems" },
  { n: "Samples", p: "/samples", i: "📦", c: "music", d: "Sample library" },
  { n: "Sounds", p: "/sounds", i: "🔊", c: "music", d: "Sound library" },
  { n: "SFX", p: "/sfx", i: "💥", c: "music", d: "Sound effects" },
  { n: "Mix & Master", p: "/mix-master", i: "🎛️", c: "music", d: "Mixing and mastering suite" },
  { n: "Mastering", p: "/mastering", i: "💿", c: "music", d: "AI mastering" },
  { n: "Vocal Removal", p: "/vocal-removal", i: "🎤", c: "music", d: "Isolate or remove vocals" },
  { n: "Audio Cleanup", p: "/audio-cleanup", i: "🧹", c: "music", d: "Clean up noisy audio" },
  { n: "Cover Art", p: "/cover-art", i: "💿", c: "music", d: "AI cover art for releases" },

  // ---- Images & Brand ----
  { n: "Thumbnail Maker", p: "/thumbnail-maker", i: "🎨", c: "images", d: "Design click-magnet thumbnails" },
  { n: "Thumbnails", p: "/thumbnail", i: "🖼️", c: "images", d: "Thumbnail tools gallery" },
  { n: "Thumbnail A/B Test", p: "/thumbnail-test", i: "🧪", c: "images", d: "Test which thumbnail wins" },
  { n: "Logo Maker", p: "/logo-maker", i: "✒️", c: "images", d: "AI logo design" },
  { n: "Branding Kit", p: "/branding-kit", i: "💼", c: "images", d: "Logos, intros, outros, stream bundles" },
  { n: "Stream Pack", p: "/stream-pack", i: "📡", c: "images", d: "Overlays, alerts, panels for streaming" },

  // ---- Content & Writing ----
  { n: "Hook Studio", p: "/hooks", i: "🪝", c: "content", d: "Hooks + virality pre-flight check" },
  { n: "Virality Check", p: "/virality-check", i: "📈", c: "content", d: "Score an idea before you post" },
  { n: "Titles", p: "/titles", i: "📝", c: "content", d: "Title generator" },
  { n: "Script Writer", p: "/script-writer", i: "✍️", c: "content", d: "AI scripts for videos" },
  { n: "Comment Replies", p: "/comment-replies", i: "💬", c: "content", d: "AI replies to comments" },
  { n: "Content Randomizer", p: "/randomizer", i: "🎲", c: "content", d: "Random content ideas (chat dice)" },
  { n: "Content Calendar", p: "/content-calendar", i: "📅", c: "content", d: "Plan your posting schedule" },
  { n: "Podcast", p: "/podcast", i: "🎙️", c: "content", d: "Podcast creation tools" },

  // ---- Promote & Grow ----
  { n: "Promote", p: "/promote", i: "📣", c: "promote", d: "Promotion tools" },
  { n: "Trends", p: "/trends", i: "🔥", c: "promote", d: "What's trending now" },
  { n: "Channel Audit", p: "/channel-audit", i: "🔎", c: "promote", d: "Audit your channel for growth leaks" },
  { n: "Scheduler", p: "/scheduler", i: "🗓️", c: "promote", d: "Schedule posts" },
  { n: "Go Live", p: "/go-live", i: "🔴", c: "promote", d: "Go-live toolkit" },
  { n: "Community", p: "/community", i: "👥", c: "promote", d: "Community hub" },
  { n: "Contests", p: "/contests", i: "🏆", c: "promote", d: "Run and enter contests" },
  { n: "Collabs", p: "/collabs", i: "🤝", c: "promote", d: "Find collaborators" },
  { n: "Shoutouts", p: "/shoutouts", i: "📢", c: "promote", d: "Shoutout exchanges" },
  { n: "Gamers", p: "/gamers", i: "🎮", c: "promote", d: "Gaming creator tools" },
  { n: "Media Detector", p: "/detector", i: "🕵️", c: "promote", d: "Detect media info from URLs" },

  // ---- Money ----
  { n: "Money Coach", p: "/coach", i: "💰", c: "money", d: "AI monetization coaching" },
  { n: "Refer & Earn", p: "/referrals", i: "🤝", c: "money", d: "Refer creators, earn 25% revenue share" },
  { n: "Pricing", p: "/pricing", i: "💳", c: "money", d: "Buy Visual Bucs credit packs" },
  { n: "Credit History", p: "/credit-history", i: "🧾", c: "money", d: "Purchases and usage ledger" },
  { n: "Brand Deals", p: "/brand-deals", i: "💼", c: "money", d: "Brand deal marketplace" },
  { n: "Brand Calculator", p: "/brand-calculator", i: "🧮", c: "money", d: "Price your brand deals" },
  { n: "Sponsors", p: "/sponsors", i: "🏢", c: "money", d: "Sponsor marketplace" },
  { n: "Sponsor Dashboard", p: "/sponsors/dashboard", i: "📊", c: "money", d: "Manage your sponsorships" },
  { n: "Post a Sponsorship", p: "/sponsors/post", i: "📮", c: "money", d: "List a sponsorship opportunity" },
  { n: "Sponsorship Outreach", p: "/sponsorship-outreach", i: "✉️", c: "money", d: "AI outreach to sponsors" },
  { n: "Royalties", p: "/royalties", i: "👑", c: "money", d: "Royalty tracking" },
  { n: "Tips", p: "/tips", i: "💸", c: "money", d: "Fan tipping pages" },
  { n: "Memberships", p: "/memberships", i: "⭐", c: "money", d: "Fan memberships" },
  { n: "My Shop", p: "/my-shop", i: "🏪", c: "money", d: "Your storefront" },
  { n: "Storefronts", p: "/storefronts", i: "🏬", c: "money", d: "Browse storefronts" },
  { n: "Storefront Builder", p: "/storefronts/builder", i: "🛠️", c: "money", d: "Build your storefront" },
  { n: "Live Shopping", p: "/live-shopping", i: "🛒", c: "money", d: "Sell live on stream" },
  { n: "Merch", p: "/merch", i: "👕", c: "money", d: "Merchandise line" },
  { n: "Branding Shop", p: "/branding-shop", i: "🎨", c: "money", d: "AI-designed branding products (dropship)" },
  { n: "Jewelry Shop", p: "/jewelry-shop", i: "💎", c: "money", d: "Jewelry line (reservation)" },
  { n: "NFC Cards", p: "/nfc-cards", i: "📇", c: "money", d: "Smart NFC business cards (reservation)" },
  { n: "Label Pitch", p: "/label-pitch", i: "📨", c: "money", d: "Pitch to labels" },
  { n: "Playlist Pitch", p: "/playlist-pitch", i: "🎧", c: "money", d: "Pitch to playlist curators" },
  { n: "Distribute", p: "/distribute", i: "🌐", c: "money", d: "Push music to streaming platforms" },
  { n: "Release Checklist", p: "/release-checklist", i: "✅", c: "money", d: "Pre-release checklist" },
  { n: "Shows", p: "/shows", i: "🎪", c: "money", d: "Manage shows" },
  { n: "Tour", p: "/tour", i: "🚌", c: "money", d: "Tour planning" },
  { n: "Setlist", p: "/setlist", i: "📋", c: "money", d: "Build setlists" },

  // ---- Library & Account ----
  { n: "My Projects", p: "/my-projects", i: "📂", c: "library", d: "All your projects" },
  { n: "Generations", p: "/generations", i: "✨", c: "library", d: "Your AI generation history" },
  { n: "Artist Vault", p: "/artist-vault", i: "🗝️", c: "library", d: "Artist identities, voices, songs" },
  { n: "Choose Artist", p: "/choose-artist", i: "🎭", c: "library", d: "Pick your artist profile" },
  { n: "Import", p: "/import", i: "📥", c: "library", d: "Import media into your library" },
  { n: "Team", p: "/team", i: "👥", c: "library", d: "Team workspace" },
  { n: "Settings", p: "/settings", i: "⚙️", c: "library", d: "Account settings" },

  // ---- Learn & Business ----
  { n: "Creator Academy", p: "/academy", i: "🎓", c: "learn", d: "Courses for creators" },
  { n: "Guides", p: "/guides", i: "📖", c: "learn", d: "How-to guides" },
  { n: "LLC Guide", p: "/llc-guide", i: "📄", c: "learn", d: "Form your LLC" },
  { n: "Copyright", p: "/copyright", i: "©️", c: "learn", d: "Copyright registration help" },
  { n: "Contracts", p: "/contracts", i: "📑", c: "learn", d: "Contract templates" },
  { n: "Interview Prep", p: "/interview-prep", i: "🎤", c: "learn", d: "Prep for press interviews" },
  { n: "Press Kit", p: "/press-kit", i: "📰", c: "learn", d: "Your electronic press kit" },
  { n: "Website Builder", p: "/website-builder", i: "🌐", c: "learn", d: "AI website builder (export model)" },
  { n: "Email List", p: "/email-list", i: "📧", c: "learn", d: "Build your email list" },
  { n: "Analytics", p: "/analytics", i: "📊", c: "learn", d: "Cross-platform analytics" },
];
