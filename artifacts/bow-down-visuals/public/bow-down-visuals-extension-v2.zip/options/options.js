// Bow Down Visuals — options page logic.

const DEFAULTS = {
  apiBase: "https://bowdownvisuals.com",
  enableChat: true,
  enableContextMenus: true,
  enableYoutubeAnalyzer: true,
  enableSocialSave: true,
  enableDownloadThumb: true,
};

function $(id) {
  return document.getElementById(id);
}

async function load() {
  const s = await chrome.storage.sync.get(DEFAULTS);
  $("api-base").value = s.apiBase;
  $("opt-chat").checked = s.enableChat !== false;
  $("opt-menus").checked = s.enableContextMenus !== false;
  $("opt-youtube").checked = s.enableYoutubeAnalyzer !== false;
  $("opt-social").checked = s.enableSocialSave !== false;
  $("opt-dlthumb").checked = s.enableDownloadThumb !== false;
}

$("save").addEventListener("click", async () => {
  const apiBase = $("api-base").value.trim().replace(/\/+$/, "") || DEFAULTS.apiBase;
  // Security: only allow the production site or localhost (dev). Prevents
  // token exfiltration to arbitrary domains via social-engineered URLs.
  const allowed = /^https:\/\/(www\.)?bowdownvisuals\.com$/.test(apiBase) ||
                  /^https:\/\/bow-down-visuals-staging\.onrender\.com$/.test(apiBase) ||
                  /^http:\/\/localhost(:\d+)?$/.test(apiBase);
  if (!allowed) {
    alert("Site URL must be https://bowdownvisuals.com, the staging URL, or localhost.");
    return;
  }
  await chrome.storage.sync.set({
    apiBase,
    enableChat: $("opt-chat").checked,
    enableContextMenus: $("opt-menus").checked,
    enableYoutubeAnalyzer: $("opt-youtube").checked,
    enableSocialSave: $("opt-social").checked,
    enableDownloadThumb: $("opt-dlthumb").checked,
  });
  const msg = $("saved-msg");
  msg.classList.remove("hidden");
  setTimeout(() => msg.classList.add("hidden"), 1500);
});

document.addEventListener("DOMContentLoaded", load);
