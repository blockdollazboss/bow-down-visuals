// Bow Down Visuals — background service worker (Manifest V3)
// Command center: context menus, API calls to the site, saved-items store,
// omnibox handler, and messages from content scripts / popup.
//
// AUTH MODEL: the site uses cookie-based auth (Supabase). All fetches use
// `credentials: "include"` so the user's existing bowdownvisuals.com session
// is reused. The user must be signed in on the site in a Chrome tab first.
// NOTE: the site's API must permit CORS from this extension's origin
// (chrome-extension://<id>) for these calls to succeed; see README.

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

const DEFAULTS = {
  apiBase: "https://bowdownvisuals.com", // no trailing slash
  enableChat: true,
  enableContextMenus: true,
  enableYoutubeAnalyzer: true,
  enableSocialSave: true,
  enableDownloadThumb: true,
};

async function getSettings() {
  const stored = await chrome.storage.sync.get(DEFAULTS);
  stored.apiBase = (stored.apiBase || DEFAULTS.apiBase).replace(/\/+$/, "");
  return stored;
}

// ---------------------------------------------------------------------------
// Small API helper
// ---------------------------------------------------------------------------

function authHeaders(extra) {
  const h = Object.assign({}, extra);
  if (siteAuthToken) h["Authorization"] = "Bearer " + siteAuthToken;
  return h;
}

async function sitePost(path, body) {
  const { apiBase } = await getSettings();
  const res = await fetch(apiBase + path, {
    method: "POST",
    credentials: "include",
    headers: authHeaders({ "Content-Type": "application/json" }),
    body: JSON.stringify(body),
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* non-JSON response */
  }
  return { ok: res.ok, status: res.status, data };
}

async function siteGet(path) {
  const { apiBase } = await getSettings();
  const res = await fetch(apiBase + path, {
    method: "GET",
    credentials: "include",
    headers: authHeaders(),
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* non-JSON response */
  }
  return { ok: res.ok, status: res.status, data };
}

function errMessage(result, fallback) {
  const d = result && result.data;
  if (d && typeof d === "object") {
    return d.error || d.message || fallback;
  }
  return fallback;
}

/** Pull a text reply out of an unknown API response shape. */
function extractReply(data) {
  if (!data) return null;
  if (typeof data === "string") return data;
  return (
    data.reply ||
    data.message ||
    data.text ||
    data.response ||
    data.analysis ||
    data.breakdown ||
    (data.data && (data.data.reply || data.data.message || data.data.text)) ||
    null
  );
}

/** Pull a list of hooks out of an unknown API response shape. */
function extractHooks(data) {
  if (!data || typeof data !== "object") return [];
  const raw =
    data.hooks || (data.data && data.data.hooks) || data.results || data.items || [];
  const list = Array.isArray(raw) ? raw : [raw];
  return list
    .map((h) => (typeof h === "string" ? h : h.text || h.hook || h.title || ""))
    .filter(Boolean);
}

// ---------------------------------------------------------------------------
// Saved items (local "Saved" tab store)
// ---------------------------------------------------------------------------

const SAVED_KEY = "bdv_saved_items";
const SAVED_MAX = 200;

async function getSavedItems() {
  const { [SAVED_KEY]: items = [] } = await chrome.storage.local.get(SAVED_KEY);
  return Array.isArray(items) ? items : [];
}

async function saveLocalItem(item) {
  const items = await getSavedItems();
  const entry = {
    id:
      "bdv-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7),
    ts: Date.now(),
    kind: item.kind || "link",
    url: item.url || "",
    title: item.title || item.url || "Untitled",
    pageUrl: item.pageUrl || "",
    pageTitle: item.pageTitle || "",
    thumb: item.thumb || "",
  };
  items.unshift(entry);
  await chrome.storage.local.set({ [SAVED_KEY]: items.slice(0, SAVED_MAX) });
  return entry;
}

async function deleteSavedItem(id) {
  const items = await getSavedItems();
  await chrome.storage.local.set({
    [SAVED_KEY]: items.filter((i) => i.id !== id),
  });
}

async function clearSavedItems() {
  await chrome.storage.local.set({ [SAVED_KEY]: [] });
}

// ---------------------------------------------------------------------------
// Context menus
// ---------------------------------------------------------------------------

const MENU_IDS = {
  saveImage: "bdv-save-image",
  saveVideo: "bdv-save-video",
  saveLink: "bdv-save-link",
  genHooks: "bdv-generate-hooks",
  captionImage: "bdv-caption-image",
  analyzePage: "bdv-analyze-page",
  downloadThumb: "bdv-download-thumb",
  screenshotPage: "bdv-screenshot-page",
  repurposeVideo: "bdv-repurpose-video",
};

async function buildMenus() {
  await chrome.contextMenus.removeAll();
  const s = await getSettings();
  if (!s.enableContextMenus) return;

  chrome.contextMenus.create({
    id: MENU_IDS.saveImage,
    title: "Save image to Bow Down Visuals",
    contexts: ["image"],
  });
  chrome.contextMenus.create({
    id: MENU_IDS.saveVideo,
    title: "Save video to Bow Down Visuals",
    contexts: ["video"],
  });
  chrome.contextMenus.create({
    id: MENU_IDS.saveLink,
    title: "Save link to Bow Down Visuals",
    contexts: ["link"],
  });
  chrome.contextMenus.create({
    id: MENU_IDS.genHooks,
    title: 'Generate hooks for "%s"',
    contexts: ["selection"],
  });
  chrome.contextMenus.create({
    id: MENU_IDS.captionImage,
    title: "Write caption for this image",
    contexts: ["image"],
  });
  chrome.contextMenus.create({
    id: MENU_IDS.analyzePage,
    title: "Analyze this page with AI",
    contexts: ["page"],
  });
  chrome.contextMenus.create({
    id: MENU_IDS.screenshotPage,
    title: "Screenshot page for a thumbnail",
    contexts: ["page"],
  });
  chrome.contextMenus.create({
    id: MENU_IDS.repurposeVideo,
    title: "Repurpose this video on BDV",
    contexts: ["page"],
    documentUrlPatterns: ["https://www.youtube.com/watch*"],
  });
  if (s.enableDownloadThumb !== false) {
    chrome.contextMenus.create({
      id: MENU_IDS.downloadThumb,
      title: "Download this video's thumbnail",
      contexts: ["page"],
      documentUrlPatterns: ["https://www.youtube.com/watch*"],
    });
  }
}

chrome.runtime.onInstalled.addListener(() => {
  buildMenus();
});

chrome.runtime.onStartup.addListener(() => {
  buildMenus();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (
    area === "sync" &&
    (changes.enableContextMenus || changes.enableDownloadThumb)
  ) {
    buildMenus();
  }
});

// ---------------------------------------------------------------------------
// Feature: save media / links (site API + local Saved tab)
// ---------------------------------------------------------------------------

async function saveToLibrary(kind, url, tab, opts = {}) {
  const pageUrl = tab && tab.url ? tab.url : "";
  const pageTitle = tab && tab.title ? tab.title : "";

  // Always keep a local copy for the Saved tab, even if the site API
  // isn't wired up yet.
  await saveLocalItem({
    kind,
    url,
    title: opts.title || pageTitle || url,
    pageUrl,
    pageTitle,
    thumb: kind === "image" ? url : opts.thumb || "",
  });

  // TODO: the site needs POST /api/extension/save-media
  //   Expected request:  { kind: "image"|"video"|"link", url, pageUrl, pageTitle }
  //   Expected response: 2xx with { id } or similar on success.
  try {
    const r = await sitePost("/api/extension/save-media", {
      kind,
      url,
      pageUrl,
      pageTitle,
    });
    if (r.ok) {
      notify("Saved to Bow Down Visuals", "Added to your media library + Saved tab.");
    } else if (r.status === 401 || r.status === 403) {
      notify(
        "Saved locally",
        "Not signed in on the site — kept in the extension's Saved tab."
      );
    } else if (r.status === 404) {
      notify(
        "Saved locally",
        "Site endpoint not wired yet — kept in the extension's Saved tab."
      );
    } else {
      notify("Saved locally", errMessage(r, `Site returned ${r.status}.`));
    }
  } catch (e) {
    notify("Saved locally", "Site unreachable — kept in the extension's Saved tab.");
  }
}

// ---------------------------------------------------------------------------
// Feature: hooks (returns list; popup renders, context menu notifies)
// ---------------------------------------------------------------------------

async function fetchHooks(topic) {
  // Uses the real Hook Studio endpoint (1 credit/generation on the site).
  // ASSUMPTION: POST /api/hook-studio accepts { topic } and returns the
  // hooks under one of: hooks | data.hooks | results. Adjust once confirmed.
  const text = (topic || "").slice(0, 300);
  const r = await sitePost("/api/hook-studio", { topic: text });
  if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
  if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
  const hooks = extractHooks(r.data).slice(0, 10);
  return { ok: true, hooks };
}

async function generateHooksNotify(selectionText) {
  try {
    const res = await fetchHooks(selectionText);
    if (!res.ok) {
      const msg =
        res.error === "signed_out"
          ? "Open bowdownvisuals.com and sign in, then try again."
          : res.error;
      notify("Hook generation failed", msg);
      return;
    }
    if (!res.hooks.length) {
      notify("Hooks generated", "The site responded but no hooks were found in the reply.");
      return;
    }
    notify("Hooks ready 🦈", "• " + res.hooks.slice(0, 5).join("\n• "));
  } catch (e) {
    notify("Hook generation failed", "Network error — is bowdownvisuals.com reachable?");
  }
}

// ---------------------------------------------------------------------------
// Feature: virality check
// ---------------------------------------------------------------------------

async function viralityCheck(idea) {
  // TODO: confirm the site's virality endpoint/contract. The Hook Studio page
  // (/hooks) has a "Virality Pre-flight" check; if it exposes an API mode we
  // should call it here. For now we ask the chat API to score it.
  //   Ideal: POST /api/hook-studio { topic, mode: "virality" } -> { score, checks[] }
  const prompt =
    "You are Thy Cheat Code, a viral-content expert. Score this content idea's viral potential from 0-100 and give 3 specific fixes to make it hit harder. Be blunt and specific. Idea: " +
    String(idea).slice(0, 500);
  const r = await sitePost("/api/chat", { message: prompt });
  if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
  if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
  return { ok: true, result: extractReply(r.data) || "(empty reply)" };
}

// ---------------------------------------------------------------------------
// Feature: caption + hashtags via chat API
// ---------------------------------------------------------------------------

async function captionFor(topic) {
  const prompt =
    "You are Thy Cheat Code, a social media expert for music creators. Write one fire Instagram/TikTok caption (under 150 characters, no cringe) plus 12 high-reach hashtags for this topic. Format: caption on line 1, hashtags on line 2. Topic: " +
    String(topic).slice(0, 300);
  const r = await sitePost("/api/chat", { message: prompt });
  if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
  if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
  return { ok: true, result: extractReply(r.data) || "(empty reply)" };
}

async function captionForImage(imageUrl, pageTitle) {
  const prompt =
    "You are Thy Cheat Code, a social media expert for music creators. Write one fire Instagram/TikTok caption (under 150 characters) plus 12 high-reach hashtags for a post featuring this image" +
    (pageTitle ? ` (from a page titled "${String(pageTitle).slice(0, 120)}")` : "") +
    ". You can't see the image, so make the caption versatile and confident. Format: caption on line 1, hashtags on line 2.";
  // Note: imageUrl is kept for a future multimodal endpoint.
  void imageUrl;
  const r = await sitePost("/api/chat", { message: prompt });
  if (r.status === 401 || r.status === 403) {
    notify("Sign in required", "Open bowdownvisuals.com and sign in, then try again.");
    return;
  }
  if (!r.ok) {
    notify("Caption failed", errMessage(r, `Site returned ${r.status}.`));
    return;
  }
  notify("Caption ready 🦈", String(extractReply(r.data) || "(empty reply)").slice(0, 400));
}

// ---------------------------------------------------------------------------
// Feature: page analysis + competitor snapshot via chat API
// ---------------------------------------------------------------------------

async function analyzePage(url, title) {
  const prompt =
    "You are Thy Cheat Code, a content strategist for music creators. Analyze this page for content opportunities: what niche it's in, what content angles are working on it, and 3 specific video/post ideas a music creator could steal (ethically) from it. Be specific and blunt. Page: " +
    String(title).slice(0, 200) +
    " (" +
    String(url).slice(0, 300) +
    ")";
  const r = await sitePost("/api/chat", { message: prompt });
  if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
  if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
  return { ok: true, result: extractReply(r.data) || "(empty reply)" };
}

async function competitorSnapshot(profileUrl) {
  const prompt =
    "You are Thy Cheat Code, a competitive-intelligence analyst for music creators. Give me a competitor snapshot for this social profile URL: " +
    String(profileUrl).slice(0, 300) +
    ". Cover: likely niche + audience, content pillars they're probably running, 3 things they're doing right, 2 gaps a new creator could exploit, and 1 content series idea to outflank them. If you can't fetch the URL, give the framework with sharp generic-but-actionable guidance for a music creator niche and say what you'd need (handle, platform, follower count) to go deeper.";
  const r = await sitePost("/api/chat", { message: prompt });
  if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
  if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
  return { ok: true, result: extractReply(r.data) || "(empty reply)" };
}

// ---------------------------------------------------------------------------
// Feature: download a YouTube video's thumbnail
// ---------------------------------------------------------------------------

async function downloadThumbnail(tab) {
  const m = (tab && tab.url ? tab.url : "").match(/[?&]v=([A-Za-z0-9_-]{11})/);
  if (!m) {
    notify("No video detected", "Open a YouTube watch page first.");
    return;
  }
  const videoId = m[1];
  const url = `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`;
  try {
    await chrome.downloads.download({
      url,
      filename: `bdv-thumbnail-${videoId}.jpg`,
      saveAs: false,
    });
    notify("Thumbnail downloading", "Saved as bdv-thumbnail-" + videoId + ".jpg");
  } catch (e) {
    notify("Download failed", "Couldn't start the download.");
  }
}

// ---------------------------------------------------------------------------
// Feature: YouTube thumbnail analysis (called from the content script)
// ---------------------------------------------------------------------------

async function analyzeThumbnail({ videoId, videoTitle, thumbnailUrl }) {
  // TODO: the site needs POST /api/extension/analyze-thumbnail
  //   Expected request:  { videoId, videoTitle, thumbnailUrl }
  //   Expected response: 2xx with { analysis } (markdown/text).
  try {
    const r = await sitePost("/api/extension/analyze-thumbnail", {
      videoId,
      videoTitle,
      thumbnailUrl,
    });
    if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
    if (r.status === 404) return { ok: false, error: "not_wired_up" };
    if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
    const d = r.data || {};
    const analysis =
      d.analysis || d.breakdown || d.insights || d.result || JSON.stringify(d);
    return { ok: true, analysis: String(analysis) };
  } catch (e) {
    return { ok: false, error: "network" };
  }
}

// ---------------------------------------------------------------------------
// Omnibox: `bdv` + Tab, then a prompt
// ---------------------------------------------------------------------------

chrome.omnibox.onInputChanged.addListener((text, suggest) => {
  suggest([
    {
      content: text + " ",
      description: "Ask Thy Cheat Code: " + text,
    },
  ]);
});

chrome.omnibox.onInputEntered.addListener(async (text) => {
  const query = text.trim();
  if (!query) return;
  // Stash it so the next popup open pre-fills the chat box.
  await chrome.storage.local.set({ bdv_pending_query: query });
  try {
    const r = await sitePost("/api/chat", { message: query });
    if (r.status === 401 || r.status === 403) {
      notify("Sign in required", "Open bowdownvisuals.com and sign in, then use bdv again.");
      return;
    }
    if (!r.ok) {
      notify("Thy Cheat Code", errMessage(r, `Site returned ${r.status}.`));
      return;
    }
    notify("🦈 Thy Cheat Code", String(extractReply(r.data) || "(empty reply)").slice(0, 400));
  } catch (e) {
    notify("Thy Cheat Code", "Couldn't reach bowdownvisuals.com.");
  }
});

// ---------------------------------------------------------------------------
// Menu click dispatch
// ---------------------------------------------------------------------------

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  switch (info.menuItemId) {
    case MENU_IDS.saveImage:
      if (info.srcUrl) await saveToLibrary("image", info.srcUrl, tab);
      break;
    case MENU_IDS.saveVideo:
      if (info.srcUrl) await saveToLibrary("video", info.srcUrl, tab);
      break;
    case MENU_IDS.saveLink:
      if (info.linkUrl) await saveToLibrary("link", info.linkUrl, tab);
      break;
    case MENU_IDS.genHooks:
      if (info.selectionText) await generateHooksNotify(info.selectionText);
      break;
    case MENU_IDS.captionImage:
      if (info.srcUrl) {
        await saveLocalItem({
          kind: "image",
          url: info.srcUrl,
          title: (tab && tab.title) || info.srcUrl,
          pageUrl: tab && tab.url,
          pageTitle: tab && tab.title,
          thumb: info.srcUrl,
        });
        await captionForImage(info.srcUrl, tab && tab.title);
      }
      break;
    case MENU_IDS.analyzePage:
      if (tab && tab.url) {
        await saveLocalItem({
          kind: "link",
          url: tab.url,
          title: tab.title || tab.url,
          pageUrl: tab.url,
          pageTitle: tab.title,
        });
        const res = await analyzePage(tab.url, tab.title || "");
        notify(
          "🦈 Page analysis",
          res.ok ? String(res.result).slice(0, 400) : res.error === "signed_out"
            ? "Sign in on bowdownvisuals.com first."
            : String(res.error).slice(0, 300)
        );
      }
      break;
    case MENU_IDS.downloadThumb:
      await downloadThumbnail(tab);
      break;
    case MENU_IDS.screenshotPage:
      await screenshotPage(tab);
      break;
    case MENU_IDS.repurposeVideo:
      await openSitePath("/promo-clip");
      break;
  }
});

// ---------------------------------------------------------------------------
// v2: site API integrations — bonus, wheel, referrals, credits
// ---------------------------------------------------------------------------

async function getBonusStatus() {
  // GET /api/bonus/status -> { streak, canClaimDaily, bonusCredits,
  //   wheelCooldownSeconds, ... }
  const r = await siteGet("/api/bonus/status");
  if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
  if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
  return { ok: true, status: r.data };
}

async function claimDailyBonus() {
  // POST /api/bonus/claim-daily -> { claimed, streak, bonusGranted, ... }
  const r = await sitePost("/api/bonus/claim-daily", {});
  if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
  if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
  return { ok: true, result: r.data };
}

async function spinJackpotWheel() {
  // POST /api/bonus/spin-wheel -> { spun, prize, label, isJackpot }
  const r = await sitePost("/api/bonus/spin-wheel", {});
  if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
  if (r.status === 429) {
    const d = r.data || {};
    return { ok: false, error: "cooldown", cooldownSeconds: d.cooldownSeconds };
  }
  if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
  return { ok: true, result: r.data };
}

async function getReferralInfo() {
  // GET /api/referrals/me -> { code, totalReferrals, creditsEarned, tier, ... }
  const r = await siteGet("/api/referrals/me");
  if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
  if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
  return { ok: true, info: r.data };
}

async function getCreditsHistory() {
  // GET /api/credits/history -> { purchases[], usage[] }
  const r = await siteGet("/api/credits/history");
  if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
  if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
  return { ok: true, history: r.data };
}

// ---------------------------------------------------------------------------
// v2: content idea dice — random idea + angles via the site's chat API
// ---------------------------------------------------------------------------

const DICE_NICHES = [
  "behind-the-scenes studio life",
  "artist money and music business",
  "viral challenges and trends",
  "fan engagement and community",
  "music creation process",
  "live performance moments",
  "storytelling about the grind",
  "collaborations and features",
];

async function rollIdeaDice() {
  const niche = DICE_NICHES[Math.floor(Math.random() * DICE_NICHES.length)];
  const prompt =
    "You are Thy Cheat Code, a viral content strategist. Roll me ONE random content idea " +
    "in the niche of " + niche + " for a music creator. Give: the idea title, the hook " +
    "(first 3 seconds), the format (talking head / b-roll / performance / text-overlay), " +
    "and why it could pop. Keep it punchy — under 120 words total.";
  const r = await sitePost("/api/chat", { message: prompt });
  if (r.status === 401 || r.status === 403) return { ok: false, error: "signed_out" };
  if (!r.ok) return { ok: false, error: errMessage(r, `Site returned ${r.status}.`) };
  return { ok: true, result: extractReply(r.data) || "(empty reply)", niche };
}

// ---------------------------------------------------------------------------
// v2: screenshot the visible tab (for thumbnails)
// ---------------------------------------------------------------------------

async function screenshotPage(tab) {
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(
      tab && tab.windowId ? tab.windowId : undefined,
      { format: "png" }
    );
    const ts = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
    await chrome.downloads.download({
      url: dataUrl,
      filename: `bdv-screenshot-${ts}.png`,
      saveAs: false,
    });
    notify("Screenshot saved", "Open the site's Thumbnail Maker to turn it into a thumbnail.");
  } catch (e) {
    notify("Screenshot failed", "Couldn't capture this tab (some pages block it).");
  }
}

async function openSitePath(path) {
  const { apiBase } = await getSettings();
  chrome.tabs.create({ url: apiBase.replace(/\/+$/, "") + path });
}

// ---------------------------------------------------------------------------
// Messages from content scripts / popup / options
// ---------------------------------------------------------------------------

// Site auth token (relayed by content/site-auth.js from bowdownvisuals.com).
// The API requires `Authorization: Bearer`, cookies alone are ignored.
let siteAuthToken = null;
chrome.storage.local.get("siteAuthToken").then((r) => {
  if (r.siteAuthToken) siteAuthToken = r.siteAuthToken;
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const t = msg && msg.type;

  if (t === "site-auth-token") {
    siteAuthToken = msg.token || null;
    chrome.storage.local.set({ siteAuthToken: siteAuthToken });
    sendResponse({ ok: true });
    return false;
  }

  if (t === "BDV_ANALYZE_THUMBNAIL") {
    analyzeThumbnail(msg.payload).then(sendResponse);
    return true;
  }
  if (t === "BDV_CHAT_STATUS") {
    siteGet("/api/chat/status")
      .then((r) => sendResponse({ ok: r.ok, status: r.status, data: r.data }))
      .catch(() => sendResponse({ ok: false, status: 0 }));
    return true;
  }
  if (t === "BDV_CHAT_SEND") {
    // ASSUMPTION: POST /api/chat accepts { message } and returns the reply
    // under one of: reply | message | text | response.
    sitePost("/api/chat", { message: msg.message })
      .then((r) => sendResponse({ ok: r.ok, status: r.status, data: r.data }))
      .catch(() => sendResponse({ ok: false, status: 0 }));
    return true;
  }
  if (t === "BDV_HOOKS") {
    fetchHooks(msg.topic)
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: "network" }));
    return true;
  }
  if (t === "BDV_VIRALITY") {
    viralityCheck(msg.idea)
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: "network" }));
    return true;
  }
  if (t === "BDV_CAPTION") {
    captionFor(msg.topic)
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: "network" }));
    return true;
  }
  if (t === "BDV_ANALYZE_PAGE") {
    analyzePage(msg.url, msg.title)
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: "network" }));
    return true;
  }
  if (t === "BDV_COMPETITOR") {
    competitorSnapshot(msg.url)
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: "network" }));
    return true;
  }
  // ---- v2: money hub ----
  if (t === "BDV_BONUS_STATUS") {
    getBonusStatus()
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: "network" }));
    return true;
  }
  if (t === "BDV_BONUS_CLAIM") {
    claimDailyBonus()
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: "network" }));
    return true;
  }
  if (t === "BDV_BONUS_SPIN") {
    spinJackpotWheel()
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: "network" }));
    return true;
  }
  if (t === "BDV_REFERRAL") {
    getReferralInfo()
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: "network" }));
    return true;
  }
  if (t === "BDV_CREDITS_HISTORY") {
    getCreditsHistory()
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: "network" }));
    return true;
  }
  if (t === "BDV_IDEA_DICE") {
    rollIdeaDice()
      .then(sendResponse)
      .catch(() => sendResponse({ ok: false, error: "network" }));
    return true;
  }
  if (t === "BDV_SAVE_LOCAL") {
    saveLocalItem(msg.item || {})
      .then((entry) => sendResponse({ ok: true, entry }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (t === "BDV_GET_SAVED") {
    getSavedItems()
      .then((items) => sendResponse({ ok: true, items }))
      .catch(() => sendResponse({ ok: false, items: [] }));
    return true;
  }
  if (t === "BDV_DELETE_SAVED") {
    deleteSavedItem(msg.id)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (t === "BDV_CLEAR_SAVED") {
    clearSavedItems()
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (t === "BDV_CONSUME_PENDING_QUERY") {
    // Popup asks for the omnibox-stashed query once, then clears it.
    chrome.storage.local.get("bdv_pending_query").then(({ bdv_pending_query }) => {
      chrome.storage.local.remove("bdv_pending_query");
      sendResponse({ query: bdv_pending_query || "" });
    });
    return true;
  }
  return false;
});

// ---------------------------------------------------------------------------
// Notifications helper
// ---------------------------------------------------------------------------

function notify(title, message) {
  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: "Bow Down Visuals — " + title,
    message: String(message).slice(0, 500),
  });
}
