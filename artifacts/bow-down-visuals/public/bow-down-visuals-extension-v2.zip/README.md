# Bow Down Visuals — Content Creator Cheat Code (Chrome Extension)

A Manifest V3 Chrome extension that puts **Thy Cheat Code** in your browser as
a full creator command center: tabbed popup (Chat / Tools / Analyze / Money /
Saved), the complete site tool directory, right-click AI tools, YouTube +
TikTok + Instagram helpers, daily bonus + jackpot wheel + referrals without
leaving the browser, an omnibox command, and a keyboard shortcut — all in the
gold/black Bow Down Visuals style.

## Features (v2.0 — "one-stop shop")

### Popup — command center (toolbar icon, or `Ctrl+Shift+B` / `Cmd+Shift+B`)

| Tab | Feature | Status |
|---|---|---|
| 💬 **Chat** | Thy Cheat Code AI chat + credit balance pill | ✅ Live via `POST /api/chat` |
| 💬 **Chat** | 📄 Attach-page button — sends current tab (title, URL, selected text) as AI context | ✅ Client-side, uses `POST /api/chat` |
| 🛠️ **Tools** | Quick generate: hooks (1 credit), caption + hashtags, virality check, 🎲 content-idea dice | ✅ Live via site APIs |
| 🛠️ **Tools** | Searchable directory of **~100 site tools** in 9 categories (Video, Music, Images & Brand, Content, Promote, Money, Library, Learn) — one click opens each on the site | ✅ Local data, deep links |
| 🔍 **Analyze** | Analyze current page (niche, what's working, 3 stealable ideas) | ✅ Live via `POST /api/chat` prompt |
| 🔍 **Analyze** | YouTube video analyzer (auto-detects watch pages) | ⚠️ UI live, API stubbed — needs site endpoint |
| 🔍 **Analyze** | Competitor snapshot (any social profile URL) | ✅ Live via `POST /api/chat` prompt |
| 💰 **Money** | Daily bonus: streak display + one-click claim | ✅ Live via `POST /api/bonus/claim-daily` |
| 💰 **Money** | Jackpot wheel: cooldown display + spin from the popup | ✅ Live via `POST /api/bonus/spin-wheel` |
| 💰 **Money** | Refer & Earn: stats, tier, copyable `?ref=CODE` link | ✅ Live via `GET /api/referrals/me` |
| 💰 **Money** | Recent Visual Buc usage + Buy Visual Bucs link | ✅ Live via `GET /api/credits/history` |
| 📥 **Saved** | Local library of everything saved via right-click / buttons — thumbnails, timestamps, kind badges; open or delete per item | ✅ Local (`chrome.storage.local`), no site needed |

### Right-click menus

| Menu | Context | Status |
|---|---|---|
| Save image / video / link to Bow Down Visuals | image, video, link | ⚠️ Saves to Saved tab locally; site endpoint TODO |
| Generate hooks for "…" | selected text | ✅ Live (1 credit) |
| **Write caption for this image** | image | ✅ Live via chat prompt (+ saved locally) |
| **Analyze this page with AI** | page | ✅ Live via chat prompt (+ saved locally) |
| **Screenshot page for a thumbnail** | page | ✅ Captures + downloads PNG |
| **Repurpose this video** | YouTube watch pages | ✅ Opens `/promo-clip` on the site |
| **Download this video's thumbnail** | YouTube watch pages | ✅ Direct download via `chrome.downloads` |

### Content scripts

- **YouTube** (`youtube.com/watch*`): gold "🦈 Analyze thumbnail" button (AI breakdown
  overlay with view/like stats) + "📥 Copy idea to BDV" button (saves title + URL
  to the Saved tab, free).
- **TikTok / Instagram** (`tiktok.com/@*/video/*`, `instagram.com/p|reel|re/*`):
  floating gold "🦈 Save to BDV" button on video pages → Saved tab.

### Omnibox — `bdv` command

Type `bdv` + `Tab` in the address bar, type a prompt, hit Enter: the answer
comes back as a notification, and the query is pre-filled in the popup chat
next time it opens.

### Keyboard shortcut

`Ctrl+Shift+B` (Windows/Linux) / `Cmd+Shift+B` (Mac) opens the popup.
(Chrome may reserve `Ctrl+Shift+B` for the bookmarks bar toggle — if so,
remap it at `chrome://extensions/shortcuts`.)

## Load it unpacked (testing)

1. Open Chrome and go to `chrome://extensions`
2. Turn on **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select this folder: `bow-down-visuals-extension/`
5. The 🦈 icon appears in your toolbar — pin it and click to open the command center

**First run:** sign in at [bowdownvisuals.com](https://bowdownvisuals.com)
in a Chrome tab first. The extension reuses your site session cookies —
if you're signed out, the popup will tell you.

## TODO — site API endpoints needed

These features are built end-to-end in the extension but need matching
endpoints on bowdownvisuals.com before they do anything real. Each is
marked with a `TODO` comment in the source.

### 1. `POST /api/extension/save-media`
Used by the "Save image / video / link" context menus
(`background.js` → `saveToLibrary`).
- **Request:** `{ kind: "image" | "video" | "link", url, pageUrl, pageTitle }`
- **Response:** `2xx` with `{ id }` (or similar) on success; `401` when signed out
- Suggested behavior: download/store the media into the user's media library
  (same bucket the Media Importer uses), charge per the site's pricing rule if
  it burns compute, refund on failure.
- **Current fallback:** saves to the extension's local Saved tab regardless.

### 2. `POST /api/extension/analyze-thumbnail`
Used by the YouTube "Analyze thumbnail" button and the popup's Analyze tab
(`content/youtube-analyzer.js` / `popup.js` → `background.js` → `analyzeThumbnail`).
- **Request:** `{ videoId, videoTitle, thumbnailUrl }`
- **Response:** `2xx` with `{ analysis }` — markdown/text breakdown of why the
  thumbnail works or doesn't (colors, faces, text, contrast, CTR tips).
  The extension also accepts `breakdown`, `insights`, or `result` keys.
- Suggested behavior: fetch the thumbnail server-side, run it through the
  site's thumbnail-analysis AI, charge per the site's pricing rule.

### 3. `POST /api/hook-studio` virality mode (nice-to-have)
The popup's virality check currently prompts the chat API. If the site's
Hook Studio "Virality Pre-flight" ever exposes an API mode, call
`POST /api/hook-studio { topic, mode: "virality" }` → `{ score, checks[] }`
from `background.js` → `viralityCheck` for structured scores.

## API assumptions (verify against the real contracts)

The extension was written defensively — it handles multiple response shapes —
but these assumptions should be confirmed:

- `POST /api/chat` accepts `{ message }`; reply found under
  `reply | message | text | response`; credit balance under
  `credits | balance | creditsRemaining | creditBalance`.
- `GET /api/chat/status` exists and returns 401/403 when signed out
  (used for the popup's sign-in check; 404 falls back gracefully).
- `POST /api/hook-studio` accepts `{ topic }`; hooks under
  `hooks | data.hooks | results`.

## CORS note

The extension calls the site API with `credentials: "include"` from the
`chrome-extension://` origin. The site's API must allow that origin via CORS
(`Access-Control-Allow-Origin` + `Access-Control-Allow-Credentials`) or these
calls will fail. If you'd rather avoid CORS config, an alternative is routing
extension traffic through a same-origin relay page on the site.

## Permissions — why each one

- `contextMenus` — right-click items (save, hooks, caption, page analysis, thumbnail download)
- `activeTab` — read the current tab's URL/title for saving and analysis
- `storage` — options (sync) + Saved tab items and omnibox pending query (local)
- `scripting` — reserved for future active-tab helpers (currently unused)
- `notifications` — "saved ✓" / "hooks ready" / omnibox answer toasts
- `downloads` — "Download this video's thumbnail" saves the file directly
- Hosts: `https://bowdownvisuals.com/*` (API), `https://www.youtube.com/*` (analyzer).
  TikTok/Instagram access comes from the declared content-script match patterns only.
- Omnibox keyword `bdv` + `commands` (`Ctrl+Shift+B`) need no extra permissions.

No remote code is loaded or executed — every script is bundled locally.

## File map

```
manifest.json                 Manifest V3 config (omnibox, commands, content scripts)
background.js                 Service worker: menus, API calls, saved store, omnibox, message router
popup/popup.html|css|js       Tabbed command center: Chat / Tools / Analyze / Money / Saved
popup/tools-data.js           Full site tool directory (~100 tools, 9 categories)
content/youtube-analyzer.js   YouTube buttons (analyze thumbnail + copy idea) + overlay
content/youtube-analyzer.css
content/social-save.js        Floating "Save to BDV" button for TikTok / Instagram
content/social-save.css
options/options.html|css|js   Settings page (site URL + 5 feature toggles)
icons/icon{16,32,48,128}.png  Shark King logo icons
```

## Not yet (ideas)

- Trend radar while browsing TikTok/Instagram
- One-click "send video URL to repurposing pipeline"
- Screenshot-to-library capture
- Chrome Web Store publishing (parked as a future feature — see `~/workspace/bow-down-visuals-feature-requests/chrome-web-store-publish.md`)
